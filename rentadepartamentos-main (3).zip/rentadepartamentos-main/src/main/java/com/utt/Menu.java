package com.utt;

public interface Menu {
    void crear();
    void ver();
    void editar();
    void borrar();
}
